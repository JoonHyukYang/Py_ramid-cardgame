import random
from tkinter import *
class pyramid:
    
    rank = ("01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13")
    suit = ("c", "s", "d", "h")

    def __init__(self,root):
        self.a = []
        self.b = []
        self.k = 0
        self.card_deck = []
        self.Back = PhotoImage(file = "back192.gif")
        for r in self.rank:
            for s in self.suit:
                self.card_deck.append(r+s)
        random.shuffle(self.card_deck)      

        for i in range(7):
            self.a.append([])
            x = (6-i) * 80 / 2
            y = i * 98 / 2
            for j in range(i+1):
                tmp = self.card_deck.pop()
                self.a[i].append([PhotoImage(file= tmp + ".gif"),tmp[:2]])
                if i != 6:
                    self.b.append(Checkbutton(root, image=self.a[i][j][0], width="73", height="98", state=DISABLED))
                else:
                    self.b.append(Checkbutton(root, image=self.a[i][j][0], width="73", height="98", offrelief=FLAT ,selectimage=self.Back))
                self.b[self.k].place(x = x + 80*j + 40, y = 49 + y)
                self.k += 1
                
root = Tk()
root.geometry("640x500")
root.configure(bg='darkgreen')
front_end=pyramid(root)
root.mainloop()