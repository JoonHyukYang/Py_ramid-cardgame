import random
from tkinter import *
class Card:
    
    ranks = ("01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13")
    suits = ("c", "s", "d", "h")

    @staticmethod
    def fresh_deck():
        cards = []
        for s in Card.suits:
            for r in Card.ranks:
                cards.append((PhotoImage(file = r+s+".gif"),r))
        random.shuffle(cards)
        return cards